import { Component } from '@angular/core';

@Component({
  selector: 'app-reguser',
  templateUrl: './reguser.component.html',
  styleUrls: ['./reguser.component.css']
})
export class ReguserComponent {
     isDropdownShown = false;
     
}
